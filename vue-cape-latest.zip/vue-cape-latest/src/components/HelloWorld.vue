<template>
  <div class="hello">

   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <link rel="icon" href="/CPCFavicon.png">
      <title>CPC - Home</title>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@latest/css/materialdesignicons.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@latest/css/materialdesignicons.min.css">
      <link href="/css/About.aff1dad5.css" rel="prefetch">
      <link href="/css/Cashflow.b59ce3c1.css" rel="prefetch">
      <link href="/css/CreateUser.3ad086b1.css" rel="prefetch">
      <link href="/css/CreateUser~EditUser~Suppliers.58ae9d48.css" rel="prefetch">
      <link href="/css/Deliveries.76a811a3.css" rel="prefetch">
      <link href="/css/ITC.e9946991.css" rel="prefetch">
      <link href="/css/Images.dcbc6ffe.css" rel="prefetch">
      <link href="/css/Login.919d0645.css" rel="prefetch">
      <link href="/css/POView.22a711b0.css" rel="prefetch">
      <link href="/css/Paymentsdue.5bafe53b.css" rel="prefetch">
      <link href="/css/ProjectStructure.ae5ec3eb.css" rel="prefetch">
      <link href="/css/QualityControl.60bcf6a5.css" rel="prefetch">
      <link href="/css/Schedule.8da3deb0.css" rel="prefetch">
      <link href="/css/SupplierChange.0d2c88f0.css" rel="prefetch">
      <link href="/css/Suppliers.9205b3f1.css" rel="prefetch">
      <link href="/css/TaskList.9d21c0d7.css" rel="prefetch">
      <link href="/css/apartment.e906d63d.css" rel="prefetch">
      <link href="/css/chunk-1a01a158.95957f58.css" rel="prefetch">
      <link href="/css/chunk-439934a3.2090ba31.css" rel="prefetch">
      <link href="/css/chunk-786db0b1.cb8f82ba.css" rel="prefetch">
      <link href="/css/chunk-790f91b3.09d1b9a0.css" rel="prefetch">
      <link href="/css/chunk-9e8946fe.069c8b7d.css" rel="prefetch">
      <link href="/css/importData.35b2f9f7.css" rel="prefetch">
      <link href="/css/paymentCertificates.9e677874.css" rel="prefetch">
      <link href="/js/About.288aaa56.js" rel="prefetch">
      <link href="/js/Cashflow.416333ab.js" rel="prefetch">
      <link href="/js/Cashflow~ProjectStructure~TaskList.a1d1773f.js" rel="prefetch">
      <link href="/js/CreateUser.d1138db0.js" rel="prefetch">
      <link href="/js/CreateUser~EditUser~Suppliers.0a780fb2.js" rel="prefetch">
      <link href="/js/Deliveries.ae1eef95.js" rel="prefetch">
      <link href="/js/Deposits.6a39a32b.js" rel="prefetch">
      <link href="/js/EditUser.dab19bd2.js" rel="prefetch">
      <link href="/js/ITC.26884541.js" rel="prefetch">
      <link href="/js/Images.2689bb20.js" rel="prefetch">
      <link href="/js/Login.5b161f5b.js" rel="prefetch">
      <link href="/js/POView.a81c5fcf.js" rel="prefetch">
      <link href="/js/Paymentsdue.b7f11828.js" rel="prefetch">
      <link href="/js/ProjectStructure.cbf841ef.js" rel="prefetch">
      <link href="/js/QualityControl.0eac8d05.js" rel="prefetch">
      <link href="/js/Retention.6b2504cd.js" rel="prefetch">
      <link href="/js/Schedule.e585ae18.js" rel="prefetch">
      <link href="/js/SupplierChange.b1553c08.js" rel="prefetch">
      <link href="/js/Suppliers.2efac7ff.js" rel="prefetch">
      <link href="/js/TaskList.783c48d2.js" rel="prefetch">
      <link href="/js/additems.999bf3ea.js" rel="prefetch">
      <link href="/js/apartment.1fa58bed.js" rel="prefetch">
      <link href="/js/chunk-1a01a158.ac9e3d65.js" rel="prefetch">
      <link href="/js/chunk-2c3265b1.47af465a.js" rel="prefetch">
      <link href="/js/chunk-2d0cc405.227e38fc.js" rel="prefetch">
      <link href="/js/chunk-2d0f028b.fd0889b6.js" rel="prefetch">
      <link href="/js/chunk-2d237b52.56bd095e.js" rel="prefetch">
      <link href="/js/chunk-381046f4.8d743c03.js" rel="prefetch">
      <link href="/js/chunk-439934a3.543af3be.js" rel="prefetch">
      <link href="/js/chunk-594d6d48.8a216641.js" rel="prefetch">
      <link href="/js/chunk-786db0b1.12c72297.js" rel="prefetch">
      <link href="/js/chunk-790f91b3.a69009ae.js" rel="prefetch">
      <link href="/js/chunk-9e8946fe.29104604.js" rel="prefetch">
      <link href="/js/filenotfound.52f2e5e0.js" rel="prefetch">
      <link href="/js/gantt4.24e00f83.js" rel="prefetch">
      <link href="/js/importData.8053bc06.js" rel="prefetch">
      <link href="/js/paymentCertificates.37d7907e.js" rel="prefetch">
      <link href="/js/purchaseordercreate.1fd3c0b8.js" rel="prefetch">
      <link href="/css/app.fcfa0608.css" rel="preload" as="style">
      <link href="/css/chunk-vendors.d2baf54f.css" rel="preload" as="style">
      <link href="/js/app.de17f253.js" rel="preload" as="script">
      <link href="/js/chunk-vendors.b7ef3d66.js" rel="preload" as="script">
      <link href="/css/chunk-vendors.d2baf54f.css" rel="stylesheet">
      <link href="/css/app.fcfa0608.css" rel="stylesheet">
      
        
      <link rel="stylesheet" type="text/css" href="/css/Login.919d0645.css">
   
      <meta data-vue-meta="1" name="description" content="CPC HOME.">
   </head>
   <body>
      <noscript><strong>We're sorry but client doesn't work properly without JavaScript enabled. Please enable it to continue.</strong></noscript>
      <div data-app="true" class="v-application colorBack v-application--is-ltr theme--light" id="app">
         <div class="v-application--wrap">
            <header data-v-0fd0cb80="" class="mobile v-sheet theme--dark v-toolbar v-app-bar v-app-bar--fixed" data-booted="true" style="height: 64px; margin-top: 0px; transform: translateY(0px); left: 0px; right: 0px; background-color: rgb(57, 62, 70); border-color: rgb(57, 62, 70);">
               <div class="v-toolbar__content" style="height: 64px;">
                  <a data-v-0fd0cb80="" href="/" aria-current="page" class="v-btn--active v-btn v-btn--router v-btn--text theme--dark v-size--default" style="min-width: 100px; font-size: 120%;"><span class="v-btn__content">CPC Endulini</span></a>
                  <div data-v-0fd0cb80="" class="spacer"></div>
                  <h2 data-v-0fd0cb80=""> Hello Connor McLean </h2>
                  <div data-v-0fd0cb80="" class="spacer"></div>
                  <button data-v-0fd0cb80="" type="button" class="v-btn v-btn--text theme--dark v-size--default"><span class="v-btn__content"><span data-v-0fd0cb80="" class="mr-2">Logout</span><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-logout-variant theme--dark"></i></span></button>
                  <div data-v-0fd0cb80="" class="text-center">
                     <button data-v-0fd0cb80="" type="button" class="v-btn v-btn--text theme--dark v-size--default" role="button" aria-haspopup="true" aria-expanded="true"><span class="v-btn__content"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-dots-vertical theme--dark"></i></span></button>
                     <div data-v-0fd0cb80="" class="v-menu" text-align-left=""></div>
                  </div>
               </div>
            </header>
            <br><br>
            <main class="v-main" data-booted="true" style="padding: 64px 0px 0px;">
               <div class="v-main__wrap">
                  <div class="home">
                     <!---->
                     <div class="container">
                        <div class="row text-center">
                           <div class="col col-12">
                              <div class="v-image v-responsive my-3 theme--light" style="height: 500px;">
                                 <div class="v-responsive__sizer" style="padding-bottom: 32.1111%;"></div>
                                 <div class="v-image__image v-image__image--contain" style="background-image: url(&quot;https://www.cape-projects.co.za/img/CPCNewLogo.e574651b.png&quot;); background-position: center center;"></div>
                                 <div class="v-responsive__content" style="width: 900px;"></div>
                              </div>
                           </div>
                           <div class="mb-4 col">
                              <h1 class="display-2 font-weight-bold mb-3"> Welcome to Cape Projects - Endulini </h1>
                           </div>
                           <div class="mb-5 col col-12"></div>
                           <div class="mb-5 col col-12"></div>
                           <div class="mb-5 col col-12"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </main>
         </div>
         <div data-v-0fd0cb80="" role="menu" class="v-menu__content theme--dark v-menu__content--fixed menuable__content__active" style="min-width: 25%; max-width: 100%; top: 12px; left: 1415px; transform-origin: left top; z-index: 8;">
            <div data-v-0fd0cb80="" class="v-list v-sheet theme--dark">
               <div data-v-0fd0cb80="">
                  <div data-v-0fd0cb80="" class="v-list-group v-list-group--no-action">
                     <div tabindex="0" aria-expanded="false" role="button" class="v-list-group__header v-list-item v-list-item--link theme--dark">
                        <div data-v-0fd0cb80="" class="v-list-item__content">
                           <div data-v-0fd0cb80="" class="v-list-item__title" style="text-align: left; margin-left: 5%;"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-warehouse theme--dark yellow--text"></i> Construction</div>
                        </div>
                        <div class="v-list-item__icon v-list-group__header__append-icon"><i aria-hidden="true" class="v-icon notranslate mdi mdi-chevron-down theme--dark"></i></div>
                     </div>
                     <!---->
                  </div>
               </div>
               <div data-v-0fd0cb80="">
                  <div data-v-0fd0cb80="" class="v-list-group v-list-group--no-action">
                     <div tabindex="0" aria-expanded="false" role="button" class="v-list-group__header v-list-item v-list-item--link theme--dark">
                        <div data-v-0fd0cb80="" class="v-list-item__content">
                           <div data-v-0fd0cb80="" class="v-list-item__title" style="text-align: left; margin-left: 5%;"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-fridge theme--dark orange--text"></i> Purchase Orders</div>
                        </div>
                        <div class="v-list-item__icon v-list-group__header__append-icon"><i aria-hidden="true" class="v-icon notranslate mdi mdi-chevron-down theme--dark"></i></div>
                     </div>
                     <!---->
                  </div>
               </div>
               <div data-v-0fd0cb80="">
                  <div data-v-0fd0cb80="" class="v-list-group v-list-group--no-action">
                     <div tabindex="0" aria-expanded="false" role="button" class="v-list-group__header v-list-item v-list-item--link theme--dark">
                        <div data-v-0fd0cb80="" class="v-list-item__content">
                           <div data-v-0fd0cb80="" class="v-list-item__title" style="text-align: left; margin-left: 5%;"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-account-cash theme--dark teal--text"></i> Cashflow &amp; Payments</div>
                        </div>
                        <div class="v-list-item__icon v-list-group__header__append-icon"><i aria-hidden="true" class="v-icon notranslate mdi mdi-chevron-down theme--dark"></i></div>
                     </div>
                     <!---->
                  </div>
               </div>
               <div data-v-0fd0cb80="">
                  <div data-v-0fd0cb80="" class="v-list-group v-list-group--no-action">
                     <div tabindex="0" aria-expanded="false" role="button" class="v-list-group__header v-list-item v-list-item--link theme--dark">
                        <div data-v-0fd0cb80="" class="v-list-item__content">
                           <div data-v-0fd0cb80="" class="v-list-item__title" style="text-align: left; margin-left: 5%;"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-point-of-sale theme--dark orange--text text--accent-1"></i> Sales</div>
                        </div>
                        <div class="v-list-item__icon v-list-group__header__append-icon"><i aria-hidden="true" class="v-icon notranslate mdi mdi-chevron-down theme--dark"></i></div>
                     </div>
                     <!---->
                  </div>
               </div>
               <div data-v-0fd0cb80="">
                  <div data-v-0fd0cb80="" class="v-list-group v-list-group--no-action">
                     <div tabindex="0" aria-expanded="false" role="button" class="v-list-group__header v-list-item v-list-item--link theme--dark">
                        <div data-v-0fd0cb80="" class="v-list-item__content">
                           <div data-v-0fd0cb80="" class="v-list-item__title" style="text-align: left; margin-left: 5%;"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-database-import theme--dark yellow--text"></i> Setup</div>
                        </div>
                        <div class="v-list-item__icon v-list-group__header__append-icon"><i aria-hidden="true" class="v-icon notranslate mdi mdi-chevron-down theme--dark"></i></div>
                     </div>
                     <!---->
                  </div>
               </div>
               <div data-v-0fd0cb80="">
                  <div data-v-0fd0cb80="" class="v-list-group v-list-group--no-action">
                     <div tabindex="0" aria-expanded="false" role="button" class="v-list-group__header v-list-item v-list-item--link theme--dark">
                        <div data-v-0fd0cb80="" class="v-list-item__content">
                           <div data-v-0fd0cb80="" class="v-list-item__title" style="text-align: left; margin-left: 5%;"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-account-cowboy-hat theme--dark light-blue--text text--accent-1"></i> User Admin</div>
                        </div>
                        <div class="v-list-item__icon v-list-group__header__append-icon"><i aria-hidden="true" class="v-icon notranslate mdi mdi-chevron-down theme--dark"></i></div>
                     </div>
                     <!---->
                  </div>
               </div>
            </div>
            <!----><!---->
            <div data-v-0fd0cb80="" class="v-list v-sheet theme--dark">
               <a data-v-0fd0cb80="" href="/about" class="v-list-item v-list-item--link theme--dark" tabindex="0" role="menuitem" id="list-item-86">
                  <div data-v-0fd0cb80="" class="v-list-item__title"><i data-v-0fd0cb80="" aria-hidden="true" class="v-icon notranslate mdi mdi-information theme--dark amber--text"></i> About</div>
               </a>
            </div>
         </div>
      </div>
      
      <div class="vuejs-notify-container"></div>
      <svg id="SvgjsSvg1001" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" focusable="false" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
         <defs id="SvgjsDefs1002"></defs>
         <polyline id="SvgjsPolyline1003" points="0,0"></polyline>
         <path id="SvgjsPath1004" d="M0 0 "></path>
      </svg>
   </body>
</div>
</template>
   <script src="/js/chunk-vendors.b7ef3d66.js"></script><script src="/js/app.de17f253.js"></script>

   <script charset="utf-8" src="/js/Login.5b161f5b.js"></script><script charset="utf-8" src="/js/chunk-2d237b52.56bd095e.js"></script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
<style data-vue-meta="vuetify" type="text/css" id="vuetify-theme-stylesheet" nonce="undefined">
 .v-application a { color: #1976d2; }
         .v-application .primary {
         background-color: #1976d2 !important;
         border-color: #1976d2 !important;
         }
         .v-application .primary--text {
         color: #1976d2 !important;
         caret-color: #1976d2 !important;
         }
         .v-application .primary.lighten-5 {
         background-color: #c7fdff !important;
         border-color: #c7fdff !important;
         }
         .v-application .primary--text.text--lighten-5 {
         color: #c7fdff !important;
         caret-color: #c7fdff !important;
         }
         .v-application .primary.lighten-4 {
         background-color: #a8e0ff !important;
         border-color: #a8e0ff !important;
         }
         .v-application .primary--text.text--lighten-4 {
         color: #a8e0ff !important;
         caret-color: #a8e0ff !important;
         }
         .v-application .primary.lighten-3 {
         background-color: #8ac5ff !important;
         border-color: #8ac5ff !important;
         }
         .v-application .primary--text.text--lighten-3 {
         color: #8ac5ff !important;
         caret-color: #8ac5ff !important;
         }
         .v-application .primary.lighten-2 {
         background-color: #6aaaff !important;
         border-color: #6aaaff !important;
         }
         .v-application .primary--text.text--lighten-2 {
         color: #6aaaff !important;
         caret-color: #6aaaff !important;
         }
         .v-application .primary.lighten-1 {
         background-color: #488fef !important;
         border-color: #488fef !important;
         }
         .v-application .primary--text.text--lighten-1 {
         color: #488fef !important;
         caret-color: #488fef !important;
         }
         .v-application .primary.darken-1 {
         background-color: #005eb6 !important;
         border-color: #005eb6 !important;
         }
         .v-application .primary--text.text--darken-1 {
         color: #005eb6 !important;
         caret-color: #005eb6 !important;
         }
         .v-application .primary.darken-2 {
         background-color: #00479b !important;
         border-color: #00479b !important;
         }
         .v-application .primary--text.text--darken-2 {
         color: #00479b !important;
         caret-color: #00479b !important;
         }
         .v-application .primary.darken-3 {
         background-color: #003180 !important;
         border-color: #003180 !important;
         }
         .v-application .primary--text.text--darken-3 {
         color: #003180 !important;
         caret-color: #003180 !important;
         }
         .v-application .primary.darken-4 {
         background-color: #001e67 !important;
         border-color: #001e67 !important;
         }
         .v-application .primary--text.text--darken-4 {
         color: #001e67 !important;
         caret-color: #001e67 !important;
         }
         .v-application .secondary {
         background-color: #424242 !important;
         border-color: #424242 !important;
         }
         .v-application .secondary--text {
         color: #424242 !important;
         caret-color: #424242 !important;
         }
         .v-application .secondary.lighten-5 {
         background-color: #c1c1c1 !important;
         border-color: #c1c1c1 !important;
         }
         .v-application .secondary--text.text--lighten-5 {
         color: #c1c1c1 !important;
         caret-color: #c1c1c1 !important;
         }
         .v-application .secondary.lighten-4 {
         background-color: #a6a6a6 !important;
         border-color: #a6a6a6 !important;
         }
         .v-application .secondary--text.text--lighten-4 {
         color: #a6a6a6 !important;
         caret-color: #a6a6a6 !important;
         }
         .v-application .secondary.lighten-3 {
         background-color: #8b8b8b !important;
         border-color: #8b8b8b !important;
         }
         .v-application .secondary--text.text--lighten-3 {
         color: #8b8b8b !important;
         caret-color: #8b8b8b !important;
         }
         .v-application .secondary.lighten-2 {
         background-color: #727272 !important;
         border-color: #727272 !important;
         }
         .v-application .secondary--text.text--lighten-2 {
         color: #727272 !important;
         caret-color: #727272 !important;
         }
         .v-application .secondary.lighten-1 {
         background-color: #595959 !important;
         border-color: #595959 !important;
         }
         .v-application .secondary--text.text--lighten-1 {
         color: #595959 !important;
         caret-color: #595959 !important;
         }
         .v-application .secondary.darken-1 {
         background-color: #2c2c2c !important;
         border-color: #2c2c2c !important;
         }
         .v-application .secondary--text.text--darken-1 {
         color: #2c2c2c !important;
         caret-color: #2c2c2c !important;
         }
         .v-application .secondary.darken-2 {
         background-color: #171717 !important;
         border-color: #171717 !important;
         }
         .v-application .secondary--text.text--darken-2 {
         color: #171717 !important;
         caret-color: #171717 !important;
         }
         .v-application .secondary.darken-3 {
         background-color: #000000 !important;
         border-color: #000000 !important;
         }
         .v-application .secondary--text.text--darken-3 {
         color: #000000 !important;
         caret-color: #000000 !important;
         }
         .v-application .secondary.darken-4 {
         background-color: #000000 !important;
         border-color: #000000 !important;
         }
         .v-application .secondary--text.text--darken-4 {
         color: #000000 !important;
         caret-color: #000000 !important;
         }
         .v-application .accent {
         background-color: #82b1ff !important;
         border-color: #82b1ff !important;
         }
         .v-application .accent--text {
         color: #82b1ff !important;
         caret-color: #82b1ff !important;
         }
         .v-application .accent.lighten-5 {
         background-color: #ffffff !important;
         border-color: #ffffff !important;
         }
         .v-application .accent--text.text--lighten-5 {
         color: #ffffff !important;
         caret-color: #ffffff !important;
         }
         .v-application .accent.lighten-4 {
         background-color: #f8ffff !important;
         border-color: #f8ffff !important;
         }
         .v-application .accent--text.text--lighten-4 {
         color: #f8ffff !important;
         caret-color: #f8ffff !important;
         }
         .v-application .accent.lighten-3 {
         background-color: #daffff !important;
         border-color: #daffff !important;
         }
         .v-application .accent--text.text--lighten-3 {
         color: #daffff !important;
         caret-color: #daffff !important;
         }
         .v-application .accent.lighten-2 {
         background-color: #bce8ff !important;
         border-color: #bce8ff !important;
         }
         .v-application .accent--text.text--lighten-2 {
         color: #bce8ff !important;
         caret-color: #bce8ff !important;
         }
         .v-application .accent.lighten-1 {
         background-color: #9fccff !important;
         border-color: #9fccff !important;
         }
         .v-application .accent--text.text--lighten-1 {
         color: #9fccff !important;
         caret-color: #9fccff !important;
         }
         .v-application .accent.darken-1 {
         background-color: #6596e2 !important;
         border-color: #6596e2 !important;
         }
         .v-application .accent--text.text--darken-1 {
         color: #6596e2 !important;
         caret-color: #6596e2 !important;
         }
         .v-application .accent.darken-2 {
         background-color: #467dc6 !important;
         border-color: #467dc6 !important;
         }
         .v-application .accent--text.text--darken-2 {
         color: #467dc6 !important;
         caret-color: #467dc6 !important;
         }
         .v-application .accent.darken-3 {
         background-color: #2364aa !important;
         border-color: #2364aa !important;
         }
         .v-application .accent--text.text--darken-3 {
         color: #2364aa !important;
         caret-color: #2364aa !important;
         }
         .v-application .accent.darken-4 {
         background-color: #004c90 !important;
         border-color: #004c90 !important;
         }
         .v-application .accent--text.text--darken-4 {
         color: #004c90 !important;
         caret-color: #004c90 !important;
         }
         .v-application .error {
         background-color: #ff5252 !important;
         border-color: #ff5252 !important;
         }
         .v-application .error--text {
         color: #ff5252 !important;
         caret-color: #ff5252 !important;
         }
         .v-application .error.lighten-5 {
         background-color: #ffe4d5 !important;
         border-color: #ffe4d5 !important;
         }
         .v-application .error--text.text--lighten-5 {
         color: #ffe4d5 !important;
         caret-color: #ffe4d5 !important;
         }
         .v-application .error.lighten-4 {
         background-color: #ffc6b9 !important;
         border-color: #ffc6b9 !important;
         }
         .v-application .error--text.text--lighten-4 {
         color: #ffc6b9 !important;
         caret-color: #ffc6b9 !important;
         }
         .v-application .error.lighten-3 {
         background-color: #ffa99e !important;
         border-color: #ffa99e !important;
         }
         .v-application .error--text.text--lighten-3 {
         color: #ffa99e !important;
         caret-color: #ffa99e !important;
         }
         .v-application .error.lighten-2 {
         background-color: #ff8c84 !important;
         border-color: #ff8c84 !important;
         }
         .v-application .error--text.text--lighten-2 {
         color: #ff8c84 !important;
         caret-color: #ff8c84 !important;
         }
         .v-application .error.lighten-1 {
         background-color: #ff6f6a !important;
         border-color: #ff6f6a !important;
         }
         .v-application .error--text.text--lighten-1 {
         color: #ff6f6a !important;
         caret-color: #ff6f6a !important;
         }
         .v-application .error.darken-1 {
         background-color: #df323b !important;
         border-color: #df323b !important;
         }
         .v-application .error--text.text--darken-1 {
         color: #df323b !important;
         caret-color: #df323b !important;
         }
         .v-application .error.darken-2 {
         background-color: #bf0025 !important;
         border-color: #bf0025 !important;
         }
         .v-application .error--text.text--darken-2 {
         color: #bf0025 !important;
         caret-color: #bf0025 !important;
         }
         .v-application .error.darken-3 {
         background-color: #9f0010 !important;
         border-color: #9f0010 !important;
         }
         .v-application .error--text.text--darken-3 {
         color: #9f0010 !important;
         caret-color: #9f0010 !important;
         }
         .v-application .error.darken-4 {
         background-color: #800000 !important;
         border-color: #800000 !important;
         }
         .v-application .error--text.text--darken-4 {
         color: #800000 !important;
         caret-color: #800000 !important;
         }
         .v-application .info {
         background-color: #2196f3 !important;
         border-color: #2196f3 !important;
         }
         .v-application .info--text {
         color: #2196f3 !important;
         caret-color: #2196f3 !important;
         }
         .v-application .info.lighten-5 {
         background-color: #d4ffff !important;
         border-color: #d4ffff !important;
         }
         .v-application .info--text.text--lighten-5 {
         color: #d4ffff !important;
         caret-color: #d4ffff !important;
         }
         .v-application .info.lighten-4 {
         background-color: #b5ffff !important;
         border-color: #b5ffff !important;
         }
         .v-application .info--text.text--lighten-4 {
         color: #b5ffff !important;
         caret-color: #b5ffff !important;
         }
         .v-application .info.lighten-3 {
         background-color: #95e8ff !important;
         border-color: #95e8ff !important;
         }
         .v-application .info--text.text--lighten-3 {
         color: #95e8ff !important;
         caret-color: #95e8ff !important;
         }
         .v-application .info.lighten-2 {
         background-color: #75ccff !important;
         border-color: #75ccff !important;
         }
         .v-application .info--text.text--lighten-2 {
         color: #75ccff !important;
         caret-color: #75ccff !important;
         }
         .v-application .info.lighten-1 {
         background-color: #51b0ff !important;
         border-color: #51b0ff !important;
         }
         .v-application .info--text.text--lighten-1 {
         color: #51b0ff !important;
         caret-color: #51b0ff !important;
         }
         .v-application .info.darken-1 {
         background-color: #007cd6 !important;
         border-color: #007cd6 !important;
         }
         .v-application .info--text.text--darken-1 {
         color: #007cd6 !important;
         caret-color: #007cd6 !important;
         }
         .v-application .info.darken-2 {
         background-color: #0064ba !important;
         border-color: #0064ba !important;
         }
         .v-application .info--text.text--darken-2 {
         color: #0064ba !important;
         caret-color: #0064ba !important;
         }
         .v-application .info.darken-3 {
         background-color: #004d9f !important;
         border-color: #004d9f !important;
         }
         .v-application .info--text.text--darken-3 {
         color: #004d9f !important;
         caret-color: #004d9f !important;
         }
         .v-application .info.darken-4 {
         background-color: #003784 !important;
         border-color: #003784 !important;
         }
         .v-application .info--text.text--darken-4 {
         color: #003784 !important;
         caret-color: #003784 !important;
         }
         .v-application .success {
         background-color: #4caf50 !important;
         border-color: #4caf50 !important;
         }
         .v-application .success--text {
         color: #4caf50 !important;
         caret-color: #4caf50 !important;
         }
         .v-application .success.lighten-5 {
         background-color: #dcffd6 !important;
         border-color: #dcffd6 !important;
         }
         .v-application .success--text.text--lighten-5 {
         color: #dcffd6 !important;
         caret-color: #dcffd6 !important;
         }
         .v-application .success.lighten-4 {
         background-color: #beffba !important;
         border-color: #beffba !important;
         }
         .v-application .success--text.text--lighten-4 {
         color: #beffba !important;
         caret-color: #beffba !important;
         }
         .v-application .success.lighten-3 {
         background-color: #a2ff9e !important;
         border-color: #a2ff9e !important;
         }
         .v-application .success--text.text--lighten-3 {
         color: #a2ff9e !important;
         caret-color: #a2ff9e !important;
         }
         .v-application .success.lighten-2 {
         background-color: #85e783 !important;
         border-color: #85e783 !important;
         }
         .v-application .success--text.text--lighten-2 {
         color: #85e783 !important;
         caret-color: #85e783 !important;
         }
         .v-application .success.lighten-1 {
         background-color: #69cb69 !important;
         border-color: #69cb69 !important;
         }
         .v-application .success--text.text--lighten-1 {
         color: #69cb69 !important;
         caret-color: #69cb69 !important;
         }
         .v-application .success.darken-1 {
         background-color: #2d9437 !important;
         border-color: #2d9437 !important;
         }
         .v-application .success--text.text--darken-1 {
         color: #2d9437 !important;
         caret-color: #2d9437 !important;
         }
         .v-application .success.darken-2 {
         background-color: #00791e !important;
         border-color: #00791e !important;
         }
         .v-application .success--text.text--darken-2 {
         color: #00791e !important;
         caret-color: #00791e !important;
         }
         .v-application .success.darken-3 {
         background-color: #006000 !important;
         border-color: #006000 !important;
         }
         .v-application .success--text.text--darken-3 {
         color: #006000 !important;
         caret-color: #006000 !important;
         }
         .v-application .success.darken-4 {
         background-color: #004700 !important;
         border-color: #004700 !important;
         }
         .v-application .success--text.text--darken-4 {
         color: #004700 !important;
         caret-color: #004700 !important;
         }
         .v-application .warning {
         background-color: #fb8c00 !important;
         border-color: #fb8c00 !important;
         }
         .v-application .warning--text {
         color: #fb8c00 !important;
         caret-color: #fb8c00 !important;
         }
         .v-application .warning.lighten-5 {
         background-color: #ffff9e !important;
         border-color: #ffff9e !important;
         }
         .v-application .warning--text.text--lighten-5 {
         color: #ffff9e !important;
         caret-color: #ffff9e !important;
         }
         .v-application .warning.lighten-4 {
         background-color: #fffb82 !important;
         border-color: #fffb82 !important;
         }
         .v-application .warning--text.text--lighten-4 {
         color: #fffb82 !important;
         caret-color: #fffb82 !important;
         }
         .v-application .warning.lighten-3 {
         background-color: #ffdf67 !important;
         border-color: #ffdf67 !important;
         }
         .v-application .warning--text.text--lighten-3 {
         color: #ffdf67 !important;
         caret-color: #ffdf67 !important;
         }
         .v-application .warning.lighten-2 {
         background-color: #ffc24b !important;
         border-color: #ffc24b !important;
         }
         .v-application .warning--text.text--lighten-2 {
         color: #ffc24b !important;
         caret-color: #ffc24b !important;
         }
         .v-application .warning.lighten-1 {
         background-color: #ffa72d !important;
         border-color: #ffa72d !important;
         }
         .v-application .warning--text.text--lighten-1 {
         color: #ffa72d !important;
         caret-color: #ffa72d !important;
         }
         .v-application .warning.darken-1 {
         background-color: #db7200 !important;
         border-color: #db7200 !important;
         }
         .v-application .warning--text.text--darken-1 {
         color: #db7200 !important;
         caret-color: #db7200 !important;
         }
         .v-application .warning.darken-2 {
         background-color: #bb5900 !important;
         border-color: #bb5900 !important;
         }
         .v-application .warning--text.text--darken-2 {
         color: #bb5900 !important;
         caret-color: #bb5900 !important;
         }
         .v-application .warning.darken-3 {
         background-color: #9d4000 !important;
         border-color: #9d4000 !important;
         }
         .v-application .warning--text.text--darken-3 {
         color: #9d4000 !important;
         caret-color: #9d4000 !important;
         }
         .v-application .warning.darken-4 {
         background-color: #802700 !important;
         border-color: #802700 !important;
         }
         .v-application .warning--text.text--darken-4 {
         color: #802700 !important;
         caret-color: #802700 !important;
         }
      </style>