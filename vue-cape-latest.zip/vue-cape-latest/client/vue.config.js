module.exports = {
  transpileDependencies: ["vuetify"],
};
