<template>
  <v-container>
    <h1>This is my my home</h1>
  </v-container>
</template>

<script>
export default {
  name: "homePage",

  data: () => ({}),
};
</script>
